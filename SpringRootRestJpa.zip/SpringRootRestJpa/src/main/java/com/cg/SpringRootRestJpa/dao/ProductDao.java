package com.cg.SpringRootRestJpa.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.SpringRootRestJpa.bean.Product;

public interface ProductDao extends JpaRepository<Product, Long>{
	
	@Query("from Product where id=:c")
	Optional<Product> findById(@Param("c") long id);
	
	/*@Query("from Product where id=:c")
	void deleteById(@Param("c") long id);*/
}
