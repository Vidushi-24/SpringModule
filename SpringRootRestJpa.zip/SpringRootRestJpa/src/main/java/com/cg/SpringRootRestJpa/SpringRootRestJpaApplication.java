package com.cg.SpringRootRestJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRootRestJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRootRestJpaApplication.class, args);
	}

}
