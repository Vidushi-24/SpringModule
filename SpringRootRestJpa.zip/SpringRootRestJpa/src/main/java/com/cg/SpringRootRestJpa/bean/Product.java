package com.cg.SpringRootRestJpa.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name="Products")
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqId")
    @SequenceGenerator(name="seqId", initialValue=100, allocationSize=500, sequenceName = "prod_id")
    @Column(name="id", updatable=false, nullable=false)
	private long id;
	private String name;
	private String model;
	
	@Min(5000)
	@Max(50000)
	private int price;
	private int amount;
	private int quantity;
	
	public Product() {
		super();
	}
	
	public Product(long id, String name, String model, @Min(5000) @Max(50000) int price, int amount,
			int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.price = price;
		this.amount = amount;
		this.quantity = quantity;
	}

	public int getAmount() {
		return amount;
	}



	public void setAmount(int amount) {
		this.amount = amount;
	}



	public int getQuantity() {
		return quantity;
	}



	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + ", amount=" + amount
				+ ", quantity=" + quantity + "]";
	}

}
