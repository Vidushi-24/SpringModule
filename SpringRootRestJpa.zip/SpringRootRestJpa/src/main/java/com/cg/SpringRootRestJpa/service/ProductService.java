package com.cg.SpringRootRestJpa.service;

import java.util.List;

import com.cg.SpringRootRestJpa.bean.Product;

public interface ProductService {
	public List<Product> getAllProducts();
	public List<Product> addProduct(Product pro);
	public Product getProductById(long id);
	public void deleteProduct(long id);
	public List<Product> updateProduct(long id, Product pro);
}
