package com.cg.SpringRootRestJpa.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringRootRestJpa.bean.Product;
import com.cg.SpringRootRestJpa.dao.ProductDao;



@Service
public class ProductServiceImpl implements ProductService{
   @Autowired
   ProductDao productDao;



   @Override
   public List<Product> addProduct(Product pro) {
	   int amount = pro.getAmount()*pro.getQuantity();
	   pro.setAmount(amount);
       productDao.save(pro);
       return productDao.findAll();
       
   }



   @Override
   public Product getProductById(long id) {
       return productDao.findById(id).get();
       
   }


   public void deleteProduct(long id) {
       productDao.deleteById(id);
   
       
   }



   @Override
   public List<Product> getAllProducts() {
       return productDao.findAll();
           }



   @Override
   public List<Product> updateProduct(long id, Product pro) {
       Optional<Product> optional=productDao.findById(id);
       if(optional.isPresent())
       {
           Product product=optional.get();
           product.setName(pro.getName());
           product.setModel(pro.getModel());
           product.setPrice(pro.getPrice());
           
           productDao.save(product);
           
       }
       return getAllProducts();
   }



}